import flet as ft
import os
from envios_email import enviar_correo_bienvenida
os.system("cls")

colors = {
    "fondo": "#0A0F1C",
    "gris_claro": "#2D2D2D",
    "blanco": "#FFFFFF",
    "azul_claro": "#3e7be6",
    "verde": "#4db139",
    "rojo": "#Ad1A1A",
    "negro": "#1a1a1a",
    "amarillo": "#FFA500"
}

def pag_log(page):
    from pag_log import main
    main(page)
    page.update()

def main(page: ft.Page):
    page.controls.clear()
    page.title = "REGISTER 3NCR1PT3D"
    page.bgcolor = colors["fondo"]
    page.scroll = ft.ScrollMode.AUTO  # ✅ SCROLL AGREGADO
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Intentar importar el nuevo sistema de auth
    try:
        from auth import registrar_usuario, validar_contrasena
        usar_nuevo_sistema = True
        print("✅ Usando nuevo sistema de autenticación")
    except ImportError:
        print("⚠️ Usando sistema antiguo de autenticación")
        usar_nuevo_sistema = False
        # Importar el sistema antiguo
        import json
        from pathlib import Path
        
        def registrar_usuario_antiguo(usuario, correo, contrasena):
            DATA_FILE = "data.json"
            if not os.path.exists(DATA_FILE):
                Path("data").mkdir(exist_ok=True)
                with open(DATA_FILE, "w") as f:
                    json.dump([], f)
            
            with open(DATA_FILE, "r") as f:
                usuarios = json.load(f)
            
            for u in usuarios:
                if u["usuario"] == usuario:
                    return False, "El usuario ya existe"
            
            usuarios.append({
                "usuario": usuario,
                "correo": correo,
                "contrasena": contrasena
            })
            
            with open(DATA_FILE, "w") as f:
                json.dump(usuarios, f, indent=4)
            
            return True, "Usuario registrado exitosamente"

    tituloApp = ft.Text(
        "REG1STER", 
        size=30, 
        weight="bold",
        font_family="OCR-A", 
        color=colors["azul_claro"]
    )

    nom_us = ft.TextField(
        label="Usuario", 
        width=300,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        hint_text="Mín. 3 caracteres",
        autofocus=True
    )
    
    corr_us = ft.TextField(
        label="Correo electrónico", 
        width=300,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        hint_text="ejemplo@mail.com"
    )
    
    cont_us = ft.TextField(
        label="Contraseña", 
        width=300, 
        password=True, 
        can_reveal_password=True,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        hint_text="Mín. 8 caracteres"
    )
    
    cont_us2 = ft.TextField(
        label="Confirmar contraseña", 
        width=300, 
        password=True, 
        can_reveal_password=True,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"]
    )

    fortaleza_text = ft.Text("", size=12)
    fortaleza_bar = ft.ProgressBar(
        width=300, 
        height=6, 
        value=0, 
        color=colors["rojo"],
        bgcolor=colors["gris_claro"]
    )

    def actualizar_fortaleza(e):
        pwd = cont_us.value
        if not pwd:
            fortaleza_bar.value = 0
            fortaleza_text.value = ""
            page.update()
            return
        
        puntos = 0
        if len(pwd) >= 8:
            puntos += 1
        if len(pwd) >= 12:
            puntos += 1
        if any(c.isupper() for c in pwd):
            puntos += 1
        if any(c.islower() for c in pwd):
            puntos += 1
        if any(c.isdigit() for c in pwd):
            puntos += 1
        if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in pwd):
            puntos += 1
        
        fortaleza = puntos / 6
        fortaleza_bar.value = fortaleza
        
        if fortaleza < 0.3:
            fortaleza_bar.color = colors["rojo"]
            fortaleza_text.value = "🔴 Débil"
            fortaleza_text.color = colors["rojo"]
        elif fortaleza < 0.6:
            fortaleza_bar.color = colors["amarillo"]
            fortaleza_text.value = "🟡 Media"
            fortaleza_text.color = colors["amarillo"]
        else:
            fortaleza_bar.color = colors["verde"]
            fortaleza_text.value = "🟢 Fuerte"
            fortaleza_text.color = colors["verde"]
        
        page.update()

    cont_us.on_change = actualizar_fortaleza

    loading = ft.ProgressRing(visible=False, width=30, height=30, color=colors["azul_claro"])
    mensaje = ft.Text("", size=13)

    def aceptar_click(e):
        print("🔘 Botón Registrar clickeado")

        if not all([nom_us.value, corr_us.value, cont_us.value, cont_us2.value]):
            mensaje.value = "⚠️ Por favor completa todos los campos"
            mensaje.color = colors["rojo"]
            page.update()
            print("❌ Campos incompletos") 
            return

        if cont_us.value != cont_us2.value:
            mensaje.value = "⚠️ Las contraseñas no coinciden"
            mensaje.color = colors["rojo"]
            cont_us2.error_text = "No coincide"
            page.update()
            print("❌ Contraseñas no coinciden")
            return

        loading.visible = True
        bot_aceptar.disabled = True
        mensaje.value = "Registrando usuario..."
        mensaje.color = colors["azul_claro"]
        page.update()
        
        print(f"📝 Intentando registrar: {nom_us.value}")  

        try:
            if usar_nuevo_sistema:
                print("🔐 Usando sistema NUEVO con bcrypt") 
                exito, msg = registrar_usuario(nom_us.value, corr_us.value, cont_us.value)
            else:
                print("⚠️ Usando sistema ANTIGUO (sin bcrypt)")  
                exito, msg = registrar_usuario_antiguo(nom_us.value, corr_us.value, cont_us.value)
            
            print(f"Resultado: {'✅' if exito else '❌'} - {msg}")  
            
        except Exception as ex:
            print(f"❌ ERROR en registro: {ex}")  
            import traceback
            traceback.print_exc()
            exito = False
            msg = f"Error inesperado: {str(ex)}"
        
        loading.visible = False
        bot_aceptar.disabled = False

        if exito:
            mensaje.value = f"✅ {msg}"
            mensaje.color = colors["verde"]
            page.update()

            try:
                enviar_correo_bienvenida(
                    to_email=corr_us.value,
                    username=nom_us.value
                )
                print("✅ Email enviado correctamente")
            except Exception as e:
                print("❌ Error enviando mail:", e)
            
            import time
            time.sleep(1.5)
            
            print("✅ Redirigiendo a login...")  
            pag_log(page)
        else:
            mensaje.value = f"❌ {msg}"
            mensaje.color = colors["rojo"]
            page.update()

    bot_aceptar = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.CHECK, size=18),
            ft.Text("REGISTRAR", font_family="OCR-A")
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        on_click=aceptar_click,
        width=140, 
        height=50,
        style=ft.ButtonStyle(
            bgcolor=colors["azul_claro"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        )
    )

    bot_can = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.ARROW_BACK, size=18),
            ft.Text("VOLVER", font_family="OCR-A")
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        on_click=lambda e: pag_log(page), 
        width=140, 
        height=50,
        style=ft.ButtonStyle(
            bgcolor=colors["rojo"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        )
    )

    frase = ft.Row(
        controls=[
            ft.Text("¿Tenés una cuenta? ", font_family="OCR-A", color=colors["blanco"]),
            ft.TextButton(
                "Iniciá sesión acá",
                on_click=lambda e: pag_log(page),
                style=ft.ButtonStyle(color=colors["azul_claro"])
            )
        ],
        alignment=ft.MainAxisAlignment.CENTER
    )

    requisitos = ft.Container(
        content=ft.Column([
            ft.Text("📋 Requisitos de contraseña:", size=12, weight="bold", color=colors["azul_claro"]),
            ft.Text("• Mínimo 8 caracteres", size=11, color=colors["blanco"]),
            ft.Text("• Mayúsculas y minúsculas", size=11, color=colors["blanco"]),
            ft.Text("• Al menos un número", size=11, color=colors["blanco"]),
        ], spacing=3),
        bgcolor=colors["gris_claro"],
        padding=10,
        border_radius=8,
        width=300,
        visible=usar_nuevo_sistema  
    )

    card = ft.Container(
        content=ft.Column(
            controls=[
                tituloApp,
                ft.Container(height=10),
                nom_us,
                corr_us,
                cont_us,
                fortaleza_bar,
                fortaleza_text,
                ft.Container(height=5),
                cont_us2,
                ft.Container(height=5),
                requisitos,
                ft.Container(height=10),
                loading,
                mensaje,
                ft.Container(height=5),
                ft.Row([bot_aceptar, bot_can], 
                       alignment=ft.MainAxisAlignment.CENTER, spacing=20),
                ft.Container(height=5),
                frase
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10
        ),
        bgcolor=colors["negro"],
        padding=40,
        border_radius=20,
        width=450,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=20,
            color=ft.Colors.with_opacity(0.6, colors["azul_claro"]),
            offset=ft.Offset(0, 5),
        )
    )

    page.add(card)
    page.update()
    print("✅ Página de registro cargada")  

if __name__ == "__main__":
    ft.app(target=main)