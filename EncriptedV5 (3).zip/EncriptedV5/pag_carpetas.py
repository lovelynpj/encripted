import flet as ft
import os
import shutil
os.system("cls")
from gestor_archivos import listar_carpetas_usuario, crear_carpeta_usuario

colors = {
    "fondo": "#0A0F1C",
    "azul_claro": "#3e7be6",
    "verde": "#4db139",
    "blanco": "#FFFFFF",
    "gris": "#1e1e1e",
    "card": "#121212",
    "rojo": "#Ad1A1A"
}

def main(page: ft.Page):
    page.controls.clear()
    page.title = "Carpetas"
    page.bgcolor = colors["fondo"]
    page.padding = 30
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    nombre_usuario = "3NCR1PT3D"
    modal_visible = False
    modal_renombrar = False
    carpeta_a_renombrar = None

    nombre_input = ft.TextField(
        label="Nombre de la carpeta",
        autofocus=True,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        width=300
    )

    nuevo_nombre_input = ft.TextField(
        label="Nuevo nombre de carpeta",
        autofocus=True,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        width=300
    )

    lista_container = ft.Column(
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=12
    )

    def abrir_carpeta_por_nombre(e, carpeta_nombre):
        try:
            from pag_contenido import main as pag_contenido
            page.clean()
            pag_contenido(page, nombre_usuario, carpeta_nombre)
        except Exception as ex:
            print("Error al abrir pag_contenido:", ex)
            page.snack_bar = ft.SnackBar(ft.Text(f"No se pudo abrir la carpeta: {ex}"))
            page.snack_bar.open = True
            page.update()
            
    def cargar_carpetas():
        lista_container.controls.clear()
        try:
            carpetas = listar_carpetas_usuario(nombre_usuario)
        except Exception as ex:
            page.snack_bar = ft.SnackBar(ft.Text(f"Error al listar carpetas: {ex}"))
            page.snack_bar.open = True
            page.update()
            return

        if not carpetas:
            lista_container.controls.append(
                ft.Container(
                    content=ft.Text("📂 No tenés carpetas aún", size=18, color=colors["azul_claro"], font_family="OCR-A"),
                    padding=ft.padding.all(12)
                )
            )
        else:
            for c in carpetas:
                fila = ft.Row(
                    [
                        ft.Container(
                            ft.Row([
                            ft.Icon(ft.Icons.FOLDER, size=28, color=colors["azul_claro"]),
                            ft.Column(
                                [
                                    ft.Text(c, size=16, weight=ft.FontWeight.BOLD, color=colors["blanco"]),
                                    ft.Text(f"Owner: {nombre_usuario}", size=12, color="#AAAAAA", font_family="OCR-A")
                                ],
                                tight=True
                            ),
                        ]),
                        on_click=lambda e, name=c: abrir_carpeta_por_nombre(e, name),
                        padding=ft.padding.only(left=10, top=5, bottom=5),
                        expand=True,  
                        ),
                        
                        ft.Row([
                            ft.IconButton(
                                icon=ft.Icons.DRIVE_FILE_RENAME_OUTLINE,
                                icon_color=colors["azul_claro"],
                                tooltip="Renombrar carpeta",
                                on_click=lambda e, n=c: abrir_modal_renombrar(n)
                            ),
                            ft.IconButton(
                                icon=ft.Icons.DELETE_FOREVER_ROUNDED,
                                icon_color=colors["rojo"],
                                tooltip="Eliminar carpeta",
                                on_click=lambda e, n=c: eliminar_carpeta(n)
                            ),
                        ])
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                )

                card = ft.Container(
                    content=fila,
                    padding=12,
                    width=420,
                    bgcolor=colors["card"],
                    border_radius=8,
                    margin=ft.margin.only(bottom=8)
                )
                lista_container.controls.append(card)
        page.update()

    def eliminar_carpeta(nombre_carpeta):
        base_path = os.path.join("data", "usuarios", nombre_usuario, nombre_carpeta)
        try:
            if os.path.exists(base_path):
                shutil.rmtree(base_path)
                page.snack_bar = ft.SnackBar(
                    ft.Text(f"🗑️ Carpeta '{nombre_carpeta}' eliminada"),
                    bgcolor=colors["rojo"]
                )
                page.snack_bar.open = True
                cargar_carpetas()
            else:
                page.snack_bar = ft.SnackBar(ft.Text("⚠️ Carpeta no encontrada"))
                page.snack_bar.open = True
        except Exception as ex:
            page.snack_bar = ft.SnackBar(ft.Text(f"❌ Error eliminando carpeta: {ex}"))
            page.snack_bar.open = True
        page.update()

    # ✏️ Abrir modal para renombrar
    def abrir_modal_renombrar(nombre):
        nonlocal modal_renombrar, carpeta_a_renombrar
        modal_renombrar = True
        carpeta_a_renombrar = nombre
        nuevo_nombre_input.value = nombre
        actualizar_pagina()

    # ✏️ Confirmar renombrado
    def confirmar_renombrado(e):
        nonlocal modal_renombrar, carpeta_a_renombrar
        nuevo_nombre = nuevo_nombre_input.value.strip()
        if not nuevo_nombre:
            return

        try:
            base_path = os.path.join("data", "usuarios", nombre_usuario)
            vieja = os.path.join(base_path, carpeta_a_renombrar)
            nueva = os.path.join(base_path, nuevo_nombre)
            os.rename(vieja, nueva)
            modal_renombrar = False
            page.snack_bar = ft.SnackBar(ft.Text(f"✏️ Carpeta renombrada a '{nuevo_nombre}'"), bgcolor=colors["azul_claro"])
            page.snack_bar.open = True
            cargar_carpetas()
        except Exception as ex:
            page.snack_bar = ft.SnackBar(ft.Text(f"❌ Error al renombrar: {ex}"))
            page.snack_bar.open = True
        actualizar_pagina()

    def cancelar_renombrado(e):
        nonlocal modal_renombrar
        modal_renombrar = False
        actualizar_pagina()

    # 🔙 Volver
    def volver_menu(e):
        from pag_prin import main as pag_prin
        page.clean()
        pag_prin(page)

    # 🧩 Crear carpeta
    def toggle_modal():
        nonlocal modal_visible
        modal_visible = not modal_visible
        actualizar_pagina()

    def crear_carpeta_click(e):
        toggle_modal()

    def confirmar_creacion(e):
        nonlocal modal_visible
        nombre = nombre_input.value.strip()
        if not nombre:
            page.snack_bar = ft.SnackBar(ft.Text("⚠️ Ingresá un nombre válido", font_family="OCR-A"))
            page.snack_bar.open = True
            page.update()
            return

        caracteres_invalidos = ['<', '>', ':', '"', '|', '?', '*', '\\', '/']
        if any(c in nombre for c in caracteres_invalidos):
            page.snack_bar = ft.SnackBar(ft.Text("⚠️ El nombre contiene caracteres no válidos"))
            page.snack_bar.open = True
            return

        try:
            carpetas_existentes = listar_carpetas_usuario(nombre_usuario)
            if nombre in carpetas_existentes:
                page.snack_bar = ft.SnackBar(ft.Text("⚠️ Ya existe una carpeta con ese nombre"))
                page.snack_bar.open = True
                return

            crear_carpeta_usuario(nombre_usuario, nombre)
            page.snack_bar = ft.SnackBar(ft.Text("✅ Carpeta creada con éxito"), bgcolor=colors["verde"])
            page.snack_bar.open = True
            modal_visible = False
            nombre_input.value = ""
            cargar_carpetas()
        except Exception as ex:
            page.snack_bar = ft.SnackBar(ft.Text(f"Error: {ex}"))
            page.snack_bar.open = True
        actualizar_pagina()

    def cancelar_creacion(e):
        nonlocal modal_visible
        modal_visible = False
        nombre_input.value = ""
        actualizar_pagina()

    def actualizar_pagina():
        page.clean()
        header = ft.Container(
            content=ft.Row(
                [
                    ft.IconButton(
                        icon=ft.Icons.ARROW_BACK_ROUNDED,
                        icon_color=colors["azul_claro"],
                        icon_size=28,
                        on_click=volver_menu,
                        tooltip="Volver al menú"
                    ),
                    ft.Text("📁 Tus carpetas", size=26, color=colors["azul_claro"], font_family="OCR-A")
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            width=600,
            padding=ft.padding.symmetric(horizontal=10)
        )

        boton_nueva = ft.ElevatedButton(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.CREATE_NEW_FOLDER_OUTLINED, color=colors["blanco"]),
                    ft.Text("NUEVA CARPETA", size=15, color=colors["blanco"], font_family="OCR-A")
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10
            ),
            on_click=crear_carpeta_click,
            width=420,
            bgcolor=colors["azul_claro"],
            color=colors["blanco"],
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), elevation=2)
        )

        contenido_principal = ft.Column(
            [header, ft.Container(height=12), boton_nueva, ft.Container(height=18), lista_container],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )

        # Modal de creación
        modales = []
        if modal_visible:
            modales.append(
                ft.Container(
                    content=ft.Container(
                        content=ft.Column([
                            ft.Text("Nueva Carpeta", size=20, color=colors["blanco"], weight=ft.FontWeight.BOLD, font_family="OCR-A"),
                            ft.Container(height=20),
                            nombre_input,
                            ft.Container(height=20),
                            ft.Row([
                                ft.TextButton("Cancelar", on_click=cancelar_creacion),
                                ft.ElevatedButton("Crear", on_click=confirmar_creacion, bgcolor=colors["azul_claro"])
                            ], alignment=ft.MainAxisAlignment.END)
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        bgcolor=colors["gris"],
                        padding=30,
                        border_radius=15,
                        width=400
                    ),
                    bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLACK),
                    alignment=ft.alignment.center,
                    expand=True
                )
            )

        # Modal de renombrado
        if modal_renombrar:
            modales.append(
                ft.Container(
                    content=ft.Container(
                        content=ft.Column([
                            ft.Text("Renombrar Carpeta", size=20, color=colors["blanco"], weight=ft.FontWeight.BOLD, font_family="OCR-A"),
                            ft.Container(height=20),
                            nuevo_nombre_input,
                            ft.Container(height=20),
                            ft.Row([
                                ft.TextButton("Cancelar", on_click=cancelar_renombrado),
                                ft.ElevatedButton("Guardar", on_click=confirmar_renombrado, bgcolor=colors["azul_claro"])
                            ], alignment=ft.MainAxisAlignment.END)
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        bgcolor=colors["gris"],
                        padding=30,
                        border_radius=15,
                        width=400
                    ),
                    bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLACK),
                    alignment=ft.alignment.center,
                    expand=True
                )
            )

        if modales:
            page.add(ft.Stack([contenido_principal, *modales]))
        else:
            page.add(contenido_principal)

        page.update()

    cargar_carpetas()
    actualizar_pagina()
