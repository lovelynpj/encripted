import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def enviar_correo_bienvenida(
    to_email,
    username,
    action_url="#", 
    support_email="info.encripted@gmail.com",
    sender_email="info.encripted@gmail.com",
    app_password="bnvy fimi prqn htcf"
):


    html_body = """<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bienvenido a ENCRIPTED</title></head>
<body style="margin:0;padding:0;background-color:#0b1220;font-family:Inter, 'Helvetica Neue', Arial, sans-serif;color:#ffffff;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#0b1220;padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:linear-gradient(180deg,#0f1724,#09101a);border-radius:12px;overflow:hidden;box-shadow:0 8px 30px rgba(2,6,23,.6);">
        <tr><td style="padding:20px 28px;border-bottom:1px solid rgba(255,255,255,0.08);">
          <table width="100%" role="presentation"><tr>
            <td style="vertical-align:middle;">
              <div style="font-size:20px;color:#ffffff;font-weight:700;">ENCRIPTED</div>
              <div style="font-size:13px;color:#d5e1ff;">Seguridad y cifrado simple</div>
            </td>
            <td style="text-align:right;vertical-align:middle;">
              <div style="font-size:13px;color:#8aa9ff;">¡Bienvenido!</div>
            </td>
          </tr></table>
        </td></tr>

        <tr><td style="padding:28px;">
          <h1 style="margin:0 0 12px 0;font-size:24px;color:#ffffff;font-weight:700;">Hola {{username}} 👋</h1>

          <p style="margin:0 0 18px 0;color:#d5e1ff;line-height:1.5;font-size:15px;">
            Gracias por registrarte en <strong style="color:#ffffff;">ENCRIPTED</strong>.
            Ya podés empezar a cifrar tus archivos y mantener todo seguro.
          </p>

          <p style="margin:18px 0 24px 0;color:#d5e1ff;line-height:1.5;font-size:15px;">
            Abrí la aplicación <strong style="color:#ffffff;">ENCRIPTED</strong> para iniciar sesión.
          </p>

          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr><td style="padding:16px;border-radius:8px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.05);">
              <div style="font-size:14px;color:#ffffff;margin-bottom:6px;font-weight:600;">Tu cuenta</div>
              <div style="font-size:14px;color:#d5e1ff;">Usuario: <strong style="color:#ffffff;">{{username}}</strong></div>
              <div style="font-size:13px;color:#9fc5ff;margin-top:12px;">
                Si no reconocés esta actividad, contactanos:
                <a href="mailto:{{support_email}}" style="color:#7fd4ff;text-decoration:none;">{{support_email}}</a>
              </div>
            </td></tr>
          </table>

          <p style="margin:20px 0 0 0;color:#9fbaff;font-size:13px;line-height:1.4;">
            Consejo de seguridad: nunca compartas tu contraseña. Si querés mejorar la seguridad, activá la verificación en dos pasos.
          </p>

        </td></tr>

        <tr><td style="padding:18px 28px;background:transparent;border-top:1px solid rgba(255,255,255,0.08);color:#7d93bf;font-size:12px;">
          <table role="presentation" width="100%"><tr>
            <td style="color:#7990c9;">ENCRIPTED • Seguridad hecha simple</td>
            <td style="text-align:right;color:#5f7da8;">© {{year}}</td>
          </tr></table>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>"""

    html_body = html_body.replace("{{username}}", username)\
                         .replace("{{action_url}}", action_url)\
                         .replace("{{support_email}}", support_email)\
                         .replace("{{year}}", str(__import__('datetime').datetime.now().year))

    text_body = f"""Hola {username}!

Gracias por registrarte en ENCRIPTED. Ya podés iniciar sesión desde la aplicación ENCRIPTED.

Si no fuiste vos, contactanos en {support_email}.
Para mas info escribir al: +54 351 237-9493.
Saludos,
ATT: El equipo de ENCRIPTED.
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = "Bienvenido a ENCRIPTED"
    msg["From"] = sender_email
    msg["To"] = to_email

    parte1 = MIMEText(text_body, "plain")
    parte2 = MIMEText(html_body, "html")

    msg.attach(parte1)
    msg.attach(parte2)

    # Envío
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.sendmail(sender_email, to_email, msg.as_string())
        server.quit()
        print(f"✅ Email enviado a {to_email}")
        return True
    except Exception as e:
        print("❌ Error enviando email:", e)
        return False
