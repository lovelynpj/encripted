import flet as ft
import os
import json
from gestor_archivos import listar_archivos_carpeta, leer_archivo_encriptado

colors = {
    "fondo": "#0A0F1C",
    "azul_claro": "#3e7be6",
    "verde": "#4db139",
    "blanco": "#FFFFFF",
    "gris": "#1e1e1e",
    "azul": "#048ef7"
}

def main(page: ft.Page, usuario, carpeta):
    page.controls.clear()
    page.title = f"Contenido de {carpeta}"
    page.bgcolor = colors["fondo"]
    page.padding = 30

    ruta_carpeta = os.path.join("usuarios", usuario, carpeta)
    os.makedirs(ruta_carpeta, exist_ok=True)
    ruta_publicaciones = os.path.join(ruta_carpeta, "publicaciones.json")

    if not os.path.exists(ruta_publicaciones):
        with open(ruta_publicaciones, "w") as f:
            json.dump([], f)

    with open(ruta_publicaciones, "r") as f:
        publicaciones = json.load(f)

    contenido = ft.Column(spacing=10)

    def copiar_contenido(e, texto):
        page.set_clipboard(texto)
        page.snack_bar = ft.SnackBar(ft.Text("📋 Copiado al portapapeles"))
        page.snack_bar.open = True
        page.update()

    for texto in publicaciones:
        contenido.controls.append(
            ft.Container(
                ft.Card(
                    content=ft.Container(
                        content=ft.Row([
                            ft.Text(texto, color=colors["blanco"], size=14, selectable=True, width=340),
                            ft.IconButton(
                                icon=ft.Icons.CONTENT_COPY,
                                icon_color=colors["azul_claro"],
                                tooltip="Copiar publicación",
                                on_click=lambda e, t=texto: copiar_contenido(e, t)
                            )
                        ]),
                        padding=10,
                        bgcolor=colors["gris"],
                        border_radius=10,
                        width=420,
                    )
                )
            )
        )

    dato = ft.TextField(
        label="Ingresa tu información encriptada acá",
        color=colors["blanco"],
        text_style=ft.TextStyle(font_family="OCR-A"),
        border_color=colors["azul_claro"]
    )

    archivos = listar_archivos_carpeta(usuario, carpeta)

    def ver_archivo(e):
        contenido_archivo = leer_archivo_encriptado(usuario, carpeta, e.control.data)
        dlg = ft.AlertDialog(
            title=ft.Text(e.control.data, color=colors["azul_claro"]),
            content=ft.Column([
                ft.Text(contenido_archivo, selectable=True, color=colors["blanco"]),
                ft.ElevatedButton(
                    "Copiar contenido",
                    icon=ft.Icons.CONTENT_COPY,
                    bgcolor=colors["azul_claro"],
                    color=colors["blanco"],
                    on_click=lambda ev: copiar_contenido(ev, contenido_archivo)
                )
            ], tight=True, spacing=10)
        )
        page.dialog = dlg
        dlg.open = True
        page.update()

    def volver_carpetas(e):
        from pag_carpetas import main as pag_carpetas
        page.clean()
        pag_carpetas(page)

    def publicar_cont(e):
        cont = dato.value.strip()
        if cont:
            contenido.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(cont, color=colors["blanco"], size=14, selectable=True, width=340),
                        ft.IconButton(
                            icon=ft.Icons.CONTENT_COPY,
                            icon_color=colors["azul_claro"],
                            tooltip="Copiar publicación",
                            on_click=lambda ev, t=cont: copiar_contenido(ev, t)
                        )
                    ]),
                    padding=10,
                    bgcolor=colors["gris"],
                    border_radius=10,
                    width=420
                )
            )
            publicaciones.append(cont)
            with open(ruta_publicaciones, "w") as f:
                json.dump(publicaciones, f, indent=4)

            dato.value = ""
            page.update()

    boton_pub = ft.ElevatedButton(
        content=ft.Row([
            ft.Text("Publicar",font_family="OCR-A")
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        ),
        on_click=publicar_cont,
        color=colors["blanco"],
        width=160,
        height=45,
        style=ft.ButtonStyle(
                bgcolor=colors["azul"],
                color=colors["blanco"],
                shape=ft.RoundedRectangleBorder(radius=10),
                elevation=5,
            )
    )

    volver = ft.IconButton(
        icon=ft.Icons.ARROW_BACK_ROUNDED,
        icon_color=colors["azul_claro"],
        icon_size=28,
        on_click=volver_carpetas,
        tooltip="Volver al menú"
    )

    lista = [
        ft.ElevatedButton(
            f,
            data=f,
            on_click=ver_archivo,
            width=400,
            style=ft.ButtonStyle(
                bgcolor=colors["gris"],
                color=colors["verde"],
                shape=ft.RoundedRectangleBorder(radius=10)
            )
        )
        for f in archivos
    ]

    page.add(
        ft.Column(
            [
                ft.Row([
                    volver,
                    ft.Text(f"Archivos en {carpeta}", size=24, color=colors["azul_claro"], font_family="OCR-A"),
                
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
                ),
                *lista,
                dato,
                boton_pub,
                ft.Divider(color=colors["azul_claro"]),
                ft.Text("Publicaciones", size=20, color=colors["azul_claro"], font_family="OCR-A"),
                contenido
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )
    page.update()
