import flet as ft
import json
import os

colors = {
    "fondo": "#0A0F1C",
    "card": "#131313",
    "azul_claro": "#3e7be6",
    "verde": "#4db139",
    "blanco": "#FFFFFF",
    "gris_claro": "#2D2D2D",
    "rojo": "#Ad1A1A",
}

HISTORIAL_PATH = os.path.join(os.path.dirname(__file__), "historial.json")

def main(page: ft.Page):
    page.title = "Historial"
    page.bgcolor = colors["fondo"]
    page.scroll = ft.ScrollMode.AUTO

    def ir_a_principal(e):
        from pag_prin import main as pag_prin
        page.clean()
        pag_prin(page)

    def cargar_registros():
        if os.path.exists(HISTORIAL_PATH):
            with open(HISTORIAL_PATH, "r") as f:
                return json.load(f)
        return []

    registros = cargar_registros()

    filtro_nombre = ft.TextField(
        label="Buscar archivo...",
        bgcolor=colors["gris_claro"],
        color=colors["blanco"],
        on_change=lambda e: actualizar_tabla()
    )

    filtro_accion = ft.Dropdown(
        label="Filtrar por acción",
        options=[
            ft.dropdown.Option("TODOS"),
            ft.dropdown.Option("ENCRIPTAR"),
            ft.dropdown.Option("DESENCRIPTAR"),
        ],
        value="TODOS",
        bgcolor=colors["gris_claro"],
        color=colors["blanco"],
        on_change=lambda e: actualizar_tabla(),
    )

    def borrar_historial(e):
        if os.path.exists(HISTORIAL_PATH):
            os.remove(HISTORIAL_PATH)
        page.snack_bar = ft.SnackBar(ft.Text("🧹 Historial borrado correctamente"))
        page.snack_bar.open = True
        actualizar_tabla()

    btn_borrar = ft.ElevatedButton(
        text="Borrar historial",
        color=colors["blanco"],
        bgcolor=colors["rojo"],
        on_click=borrar_historial,
    )

    tabla = ft.DataTable(
        columns=[
            ft.DataColumn(ft.Text("Archivo")),
            ft.DataColumn(ft.Text("Acción")),
            ft.DataColumn(ft.Text("Fecha")),
            ft.DataColumn(ft.Text("Ruta")),
            ft.DataColumn(ft.Text("Tamaño")),
        ],
        rows=[],
        bgcolor=colors["card"],
        border_radius=10,
        data_row_color={"hovered": colors["gris_claro"]},
        heading_row_color=colors["azul_claro"],
    )

    def actualizar_tabla():
        registros_actuales = cargar_registros()
        nombre_filtro = filtro_nombre.value.lower()
        accion_filtro = filtro_accion.value

        filas = []
        for r in registros_actuales[::-1]:
            if nombre_filtro and nombre_filtro not in r["archivo"].lower():
                continue
            if accion_filtro != "TODOS" and r["accion"] != accion_filtro:
                continue
            filas.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(r["archivo"], color=colors["blanco"])),
                        ft.DataCell(ft.Text(r["accion"], color=colors["verde"] if r["accion"]=="ENCRIPTAR" else colors["azul_claro"])),
                        ft.DataCell(ft.Text(r["fecha"], color=colors["blanco"])),
                        ft.DataCell(ft.Text(r["ruta"], color=colors["blanco"])),
                        ft.DataCell(ft.Text(r["tamano"], color=colors["blanco"])),
                    ]
                )
            )
        tabla.rows = filas
        page.update()

    actualizar_tabla()

    btn_volver=ft.IconButton(
        icon=ft.Icons.ARROW_BACK_ROUNDED,
        icon_color=colors["azul_claro"],
        icon_size=28,
        on_click=ir_a_principal,
        tooltip="Volver al menú principal"
    )

    page.add(
        ft.Column(
            [
                btn_volver,
                ft.Text("📜 HISTORIAL DE ARCHIVOS", color=colors["azul_claro"], size=24, font_family="OCR-A"),
                ft.Container(height=10),
                ft.Row(
                    [filtro_nombre, filtro_accion, btn_borrar],
                    alignment="center",
                    spacing=10,
                ),
                ft.Container(height=20),
                tabla,
            ],
            alignment="center",
            horizontal_alignment="center",
        )
    )

