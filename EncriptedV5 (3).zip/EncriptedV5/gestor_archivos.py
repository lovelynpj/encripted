import os
os.system("cls")
import flet as ft
BASE_DIR = "data/usuarios"

def eliminar_carpeta(nombre_usuario, nombre_carpeta):
    ruta_carpeta = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta)
    if os.path.exists(ruta_carpeta):
        import shutil
        shutil.rmtree(ruta_carpeta)
        return True
    return False

def renombrar_carpeta(nombre_usuario, carpeta_vieja, carpeta_nueva):
    ruta_vieja = os.path.join(BASE_DIR, nombre_usuario, carpeta_vieja)
    ruta_nueva = os.path.join(BASE_DIR, nombre_usuario, carpeta_nueva)
    if os.path.exists(ruta_vieja):
        os.rename(ruta_vieja, ruta_nueva)
        return True
    return False


def eliminar_archivo(nombre_usuario, nombre_carpeta, nombre_archivo):
    ruta_archivo = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta, nombre_archivo)
    if os.path.exists(ruta_archivo):
        os.remove(ruta_archivo)
        return True
    return False

def renombrar_archivo(nombre_usuario, nombre_carpeta, archivo_viejo, archivo_nuevo):
    ruta_vieja = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta, archivo_viejo)
    ruta_nueva = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta, archivo_nuevo)
    if os.path.exists(ruta_vieja):
        os.rename(ruta_vieja, ruta_nueva)
        return True
    return False

def crear_carpeta_usuario(nombre_usuario, nombre_carpeta):
    ruta = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta)
    os.makedirs(ruta, exist_ok=True)
    return ruta

def listar_carpetas_usuario(nombre_usuario):
    ruta_usuario = os.path.join(BASE_DIR, nombre_usuario)
    if not os.path.exists(ruta_usuario):
        return []
    return [d for d in os.listdir(ruta_usuario) if os.path.isdir(os.path.join(ruta_usuario, d))]

def listar_archivos_carpeta(nombre_usuario, nombre_carpeta):
    ruta_carpeta = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta)
    if not os.path.exists(ruta_carpeta):
        return []
    return [f for f in os.listdir(ruta_carpeta) if f.endswith(".enc")]

def leer_archivo_encriptado(nombre_usuario, nombre_carpeta, nombre_archivo):
    ruta = os.path.join(BASE_DIR, nombre_usuario, nombre_carpeta, nombre_archivo)
    with open(ruta, "r", encoding="utf-8") as f:
        return f.read()

from pathlib import Path

BASE_DATA = Path("data/usuarios")

def get_user_folder(usuario: str, subfolder: str = "mis_archivos") -> Path:
    """Devuelve la ruta base del usuario, creándola si no existe."""
    folder = BASE_DATA / usuario / subfolder
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def save_text_file_for_user(usuario: str, subfolder: str, filename: str, content: str) -> str:
    """
    Guarda contenido de texto (como tokens encriptados) en el directorio del usuario.
    Devuelve la ruta donde se guardó el archivo.
    """
    folder = get_user_folder(usuario, subfolder)
    path = folder / filename
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return str(path)

def save_bytes_file_for_user(usuario: str, subfolder: str, filename: str, data: bytes) -> str:
    """
    Guarda bytes (archivos binarios desencriptados) en el directorio del usuario.
    Devuelve la ruta donde se guardó el archivo.
    """
    folder = get_user_folder(usuario, subfolder)
    path = folder / filename
    with open(path, "wb") as f:
        f.write(data)
    return str(path)
