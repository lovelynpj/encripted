# auth.py - NUEVO ARCHIVO: Sistema de autenticación seguro
import json
import os
import bcrypt
import re
from pathlib import Path
from datetime import datetime

DATA_FILE = "data/users.json"

def init_users_file():
    """Inicializa el archivo de usuarios si no existe"""
    Path("data").mkdir(exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w") as f:
            json.dump([], f)

def validar_usuario(usuario: str) -> tuple[bool, str]:
    """Valida el formato del nombre de usuario"""
    if not usuario or len(usuario) < 3:
        return False, "Usuario debe tener al menos 3 caracteres"
    if len(usuario) > 20:
        return False, "Usuario no puede tener más de 20 caracteres"
    if not re.match("^[a-zA-Z0-9_]+$", usuario):
        return False, "Usuario solo puede contener letras, números y guion bajo"
    return True, ""

def validar_email(email: str) -> tuple[bool, str]:
    """Valida el formato del email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not email or not re.match(pattern, email):
        return False, "Email inválido"
    return True, ""

def validar_contrasena(contrasena: str) -> tuple[bool, str]:
    """Valida la fortaleza de la contraseña"""
    if not contrasena or len(contrasena) < 8:
        return False, "La contraseña debe tener al menos 8 caracteres"
    if len(contrasena) > 128:
        return False, "La contraseña es demasiado larga"
    
    # Verificar complejidad
    tiene_mayuscula = any(c.isupper() for c in contrasena)
    tiene_minuscula = any(c.islower() for c in contrasena)
    tiene_numero = any(c.isdigit() for c in contrasena)
    
    if not (tiene_mayuscula and tiene_minuscula and tiene_numero):
        return False, "La contraseña debe contener mayúsculas, minúsculas y números"
    
    return True, ""

def hash_password(password: str) -> str:
    """Hashea una contraseña usando bcrypt"""
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    """Verifica una contraseña contra su hash"""
    try:
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    except Exception:
        return False

def registrar_usuario(usuario: str, correo: str, contrasena: str) -> tuple[bool, str]:
    """
    Registra un nuevo usuario con validaciones y hash de contraseña
    Retorna: (éxito: bool, mensaje: str)
    """
    init_users_file()
    
    # Validaciones
    valido, msg = validar_usuario(usuario)
    if not valido:
        return False, msg
    
    valido, msg = validar_email(correo)
    if not valido:
        return False, msg
    
    valido, msg = validar_contrasena(contrasena)
    if not valido:
        return False, msg
    
    # Cargar usuarios existentes
    with open(DATA_FILE, "r") as f:
        usuarios = json.load(f)
    
    # Verificar si el usuario ya existe
    for u in usuarios:
        if u["usuario"] == usuario:
            return False, "El usuario ya existe"
        if u["correo"] == correo:
            return False, "El correo ya está registrado"
    
    # Hashear contraseña
    hashed = hash_password(contrasena)
    
    # Crear usuario
    nuevo_usuario = {
        "usuario": usuario,
        "correo": correo,
        "contrasena": hashed,  # ✅ HASHEADA
        "fecha_registro": datetime.now().isoformat(),
        "ultimo_acceso": None,
        "intentos_fallidos": 0,
        "bloqueado": False
    }
    
    usuarios.append(nuevo_usuario)
    
    # Guardar
    with open(DATA_FILE, "w") as f:
        json.dump(usuarios, f, indent=4)
    
    # Crear carpeta del usuario
    from pathlib import Path
    user_path = Path("data/usuarios") / usuario
    user_path.mkdir(parents=True, exist_ok=True)
    (user_path / "mis_archivos").mkdir(exist_ok=True)
    
    return True, "Usuario registrado exitosamente"

def verificar_login(usuario: str, contrasena: str) -> tuple[bool, str]:
    """
    Verifica las credenciales del usuario
    Retorna: (éxito: bool, mensaje: str)
    """
    init_users_file()
    
    try:
        with open(DATA_FILE, "r") as f:
            usuarios = json.load(f)
    except FileNotFoundError:
        return False, "No hay usuarios registrados"
    
    for idx, u in enumerate(usuarios):
        if u["usuario"] == usuario:
            # Verificar si está bloqueado
            if u.get("bloqueado", False):
                return False, "Usuario bloqueado por múltiples intentos fallidos"
            
            # Verificar contraseña
            if verify_password(contrasena, u["contrasena"]):
                # Login exitoso - resetear intentos fallidos
                u["intentos_fallidos"] = 0
                u["ultimo_acceso"] = datetime.now().isoformat()
                
                with open(DATA_FILE, "w") as f:
                    json.dump(usuarios, f, indent=4)
                
                return True, "Login exitoso"
            else:
                # Contraseña incorrecta
                u["intentos_fallidos"] = u.get("intentos_fallidos", 0) + 1
                
                if u["intentos_fallidos"] >= 5:
                    u["bloqueado"] = True
                    with open(DATA_FILE, "w") as f:
                        json.dump(usuarios, f, indent=4)
                    return False, "Usuario bloqueado por múltiples intentos fallidos"
                
                with open(DATA_FILE, "w") as f:
                    json.dump(usuarios, f, indent=4)
                
                return False, f"Contraseña incorrecta. Intentos restantes: {5 - u['intentos_fallidos']}"
    
    return False, "Usuario no encontrado"

def cambiar_contrasena(usuario: str, contrasena_actual: str, contrasena_nueva: str) -> tuple[bool, str]:
    """Cambia la contraseña del usuario"""
    # Verificar contraseña actual
    valido, msg = verificar_login(usuario, contrasena_actual)
    if not valido:
        return False, "Contraseña actual incorrecta"
    
    # Validar nueva contraseña
    valido, msg = validar_contrasena(contrasena_nueva)
    if not valido:
        return False, msg
    
    # Actualizar contraseña
    with open(DATA_FILE, "r") as f:
        usuarios = json.load(f)
    
    for u in usuarios:
        if u["usuario"] == usuario:
            u["contrasena"] = hash_password(contrasena_nueva)
            break
    
    with open(DATA_FILE, "w") as f:
        json.dump(usuarios, f, indent=4)
    
    return True, "Contraseña cambiada exitosamente"

def obtener_info_usuario(usuario: str) -> dict:
    """Obtiene información del usuario (sin contraseña)"""
    try:
        with open(DATA_FILE, "r") as f:
            usuarios = json.load(f)
        
        for u in usuarios:
            if u["usuario"] == usuario:
                info = u.copy()
                del info["contrasena"]  # No retornar el hash
                return info
        return None
    except Exception:
        return None