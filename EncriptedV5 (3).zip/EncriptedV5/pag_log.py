# pag_log.py - VERSIÓN MEJORADA
import flet as ft
import os
os.system("cls")
from auth import verificar_login  # Importar del nuevo módulo

colors = {
    "fondo": "#0A0F1C",
    "gris_claro": "#2D2D2D",
    "azul_claro": "#3e7be6",
    "verde": "#4db139",
    "rojo": "#Ad1A1A",
    "blanco": "#FFFFFF",
    "negro": "#1a1a1a",
}

def pag_prin(page, usuario):
    from pag_prin import main
    page.session.set("usuario_actual", usuario)
    page.session.set("password_cache", page.session.get("temp_password"))
    page.session.remove("temp_password")
    main(page, usuario)
    page.update()

def pag_reg(page):
    from pag_reg import main
    main(page)
    page.update()

def main(page: ft.Page):
    page.controls.clear()
    page.title = "LOGIN 3NCR1PT3D"
    page.bgcolor = colors["fondo"]
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    tituloApp = ft.Text(
        "LOG1N", 
        size=30, 
        weight="bold",
        font_family="OCR-A", 
        color=colors["azul_claro"]
    )

    nom_us = ft.TextField(
        label="Ingresar usuario", 
        width=300,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"],
        autofocus=True
    )
    
    cont_us = ft.TextField(
        label="Ingresar contraseña", 
        width=300, 
        password=True,
        can_reveal_password=True,
        border_color=colors["azul_claro"],
        focused_border_color=colors["azul_claro"]
    )

    mensaje = ft.Text("", size=14)
    
    # Progress indicator
    loading = ft.ProgressRing(visible=False, width=30, height=30, color=colors["azul_claro"])

    def aceptar_click(e):
        if not nom_us.value or not cont_us.value:
            mensaje.value = "⚠️ Por favor completa todos los campos"
            mensaje.color = colors["rojo"]
            page.update()
            return
        
        # Mostrar loading
        loading.visible = True
        bot_aceptar.disabled = True
        page.update()
        
        # Verificar login con el nuevo sistema
        valido, msg = verificar_login(nom_us.value, cont_us.value)
        
        loading.visible = False
        bot_aceptar.disabled = False
        
        if valido:
            mensaje.value = "✅ " + msg
            mensaje.color = colors["verde"]
            page.update()
            
            # Guardar contraseña temporalmente en sesión (para encriptación)
            page.session.set("temp_password", cont_us.value)
            
            # Pequeña pausa para mostrar el mensaje
            import time
            time.sleep(0.5)
            
            pag_prin(page, nom_us.value)
        else:
            mensaje.value = "❌ " + msg
            mensaje.color = colors["rojo"]
            
            # Animación de shake en error
            cont_us.error_text = "Verificá tus credenciales"
            page.update()
            
            import time
            time.sleep(1.5)
            cont_us.error_text = None
            page.update()

    bot_aceptar = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.LOGIN, size=18),
            ft.Text("INGRESAR", font_family="OCR-A")
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        on_click=aceptar_click,
        width=140, 
        height=50,
        style=ft.ButtonStyle(
            bgcolor=colors["azul_claro"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        )
    )

    bot_can = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.CLOSE, size=18),
            ft.Text("SALIR", font_family="OCR-A")
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        on_click=lambda e: page.window_close(),
        width=140, 
        height=50,
        style=ft.ButtonStyle(
            bgcolor=colors["rojo"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        )
    )

    frase = ft.Row(
        controls=[
            ft.Text("¿No tenés cuenta? ", font_family="OCR-A", color=colors["blanco"]),
            ft.TextButton(
                "Registrate acá",
                on_click=lambda e: pag_reg(page),
                style=ft.ButtonStyle(color=colors["azul_claro"])
            )
        ],
        alignment=ft.MainAxisAlignment.CENTER
    )

    # Card contenedor
    card = ft.Container(
        content=ft.Column(
            controls=[
                tituloApp,
                ft.Container(height=10),
                nom_us,
                cont_us, 
                ft.Container(height=5),
                loading,
                ft.Row([bot_aceptar, bot_can],
                       alignment=ft.MainAxisAlignment.CENTER, spacing=20),
                mensaje,
                ft.Container(height=10),
                frase
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15
        ),
        bgcolor=colors["negro"],
        padding=40,
        border_radius=20,
        width=450,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=20,
            color=ft.Colors.with_opacity(0.6, colors["azul_claro"]),
            offset=ft.Offset(0, 5),
        )
    )

    page.add(card)
    page.update()