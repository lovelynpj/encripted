# encriptacion_desencriptacion.py - VERSIÓN MEJORADA
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from pathlib import Path
import base64
import os

# Rutas
BASE_DATA = Path("data/usuarios")

def generar_clave_usuario(contrasena: str, usuario: str) -> bytes:
    """
    Genera una clave única basada en la contraseña del usuario.
    Usa el nombre de usuario como salt para consistencia.
    """
    salt = usuario.encode('utf-8').ljust(16, b'0')[:16]  # Salt de 16 bytes
    
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(contrasena.encode('utf-8')))
    return key

def get_user_key_path(usuario: str) -> Path:
    """Retorna la ruta de la clave del usuario"""
    folder = BASE_DATA / usuario
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "encryption.key"

def load_or_create_key(usuario: str, contrasena: str) -> bytes:
    """
    Carga o crea la clave de encriptación del usuario.
    Ahora basada en su contraseña.
    """
    key_path = get_user_key_path(usuario)
    
    if key_path.exists():
        with open(key_path, "rb") as f:
            return f.read()
    else:
        # Generar clave basada en contraseña
        key = generar_clave_usuario(contrasena, usuario)
        with open(key_path, "wb") as f:
            f.write(key)
        return key

def get_fernet(usuario: str, contrasena: str) -> Fernet:
    """Obtiene instancia de Fernet para el usuario"""
    key = load_or_create_key(usuario, contrasena)
    return Fernet(key)

# --- Funciones de encriptación/desencriptación ---
def encrypt_message(text: str, usuario: str, contrasena: str) -> str:
    """Encripta un texto plano y devuelve un string seguro."""
    f = get_fernet(usuario, contrasena)
    token = f.encrypt(text.encode("utf-8"))
    return token.decode("utf-8")

def decrypt_message(token: str, usuario: str, contrasena: str) -> str:
    """Desencripta un texto encriptado (token)."""
    f = get_fernet(usuario, contrasena)
    plain = f.decrypt(token.encode("utf-8"))
    return plain.decode("utf-8")

def encrypt_bytes(data: bytes, usuario: str, contrasena: str) -> bytes:
    """Encripta bytes (archivos, imágenes, etc.)."""
    f = get_fernet(usuario, contrasena)
    return f.encrypt(data)

def decrypt_bytes(token: bytes, usuario: str, contrasena: str) -> bytes:
    """Desencripta bytes previamente encriptados."""
    f = get_fernet(usuario, contrasena)
    return f.decrypt(token)

# --- Exportar/Importar clave ---
def export_key(usuario: str, export_path: str):
    """Exporta la clave del usuario a un archivo"""
    key_path = get_user_key_path(usuario)
    if key_path.exists():
        import shutil
        shutil.copy(key_path, export_path)
        return True
    return False

def import_key(usuario: str, import_path: str):
    """Importa una clave desde un archivo"""
    key_path = get_user_key_path(usuario)
    if os.path.exists(import_path):
        import shutil
        shutil.copy(import_path, key_path)
        return True
    return False

# --- Validación de clave ---
def verify_key(usuario: str, contrasena: str) -> bool:
    """Verifica que la clave del usuario sea válida"""
    try:
        f = get_fernet(usuario, contrasena)
        # Test de encriptación/desencriptación
        test = f.encrypt(b"test")
        f.decrypt(test)
        return True
    except Exception:
        return False