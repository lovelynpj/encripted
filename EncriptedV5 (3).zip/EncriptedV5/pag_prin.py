import threading
import random
import string
import time
import flet as ft
import os
os.system("cls")
from encriptar import main as encriptador_main
from desencriptar import main as desencriptador_main
import pag_encriptar, pag_desencriptar

colors = {
    "fondo": "#0A0F1C",
    "card": "#131313",
    "gris": "#1e1e1e",
    "gris_claro": "#2D2D2D",
    "gris_oscuro": "#000017",
    "blanco": "#FFFFFF",
    "azul": "#048ef7",
    "azul_claro": "#3e7be6",
    "azul_oscuro": "#070758",
    "rojo": "#Ad1A1A",
    "verde": "#4db139",
}

def main(page: ft.Page, usuario=None):
    usuario=page.session.get("usuario_actual") or "USUARIO"
    page.controls.clear()
    page.title = "---3NCR1PT3D---"
    page.padding = 30
    page.bgcolor = colors["fondo"]
    page.scroll = ft.ScrollMode.AUTO
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def texto_hacker(page: ft.Page, text_ctrl: ft.Text, final_text: str, speed=0.01, changes_per_letter=10):
        chars = string.ascii_letters + string.digits + "!@#$%&?+-"
        display = [""] * len(final_text)

        for i in range(len(final_text)):
            for _ in range(changes_per_letter):
                display[i] = random.choice(chars)
                text_ctrl.value = "".join(display)
                try:
                    text_ctrl.update()
                except Exception:
                    page.update()
                time.sleep(speed)
            display[i] = final_text[i]
            text_ctrl.value = "".join(display)
            try:
                text_ctrl.update()
            except Exception:
                page.update()
        text_ctrl.value = final_text
        try:
            text_ctrl.update()
        except Exception:
            page.update()

    def hover(e):
        e.control.scale = 1.2 if e.data == "true" else 1.0
        e.control.update()

    def hover_card(e):
        e.control.scale = 1.1 if e.data == "true" else 1.0
        e.control.update()

    def ir_a_encriptar(e):
        e.page.clean()
        pag_encriptar.main(e.page)

    def ir_a_desencriptar(e):
        e.page.clean()
        pag_desencriptar.main(e.page)

    def ir_a_bienvenida(e):
        from pag_bienv import main as pag_bienvenida
        page.clean()
        pag_bienvenida(page)

    def ir_a_encript(e):
        page.clean()
        encriptador_main(page)

    def ir_a_desencript(e):
        page.clean()
        desencriptador_main(page)

    def ir_a_carpetas(e):
        from pag_carpetas import main as pag_carpetas
        page.clean()
        pag_carpetas(page)

    header = ft.Container(
        content=ft.Row(
            [
                ft.IconButton(
                    icon=ft.Icons.ARROW_BACK_ROUNDED,
                    icon_color=colors["azul_claro"],
                    icon_size=28,
                    on_click=ir_a_bienvenida,
                    tooltip="Volver",
                ),
                ft.Text(
                    "3NCR1PT3D",
                    color=colors["azul_claro"],
                    size=36,
                    font_family="OCR-A",
                    weight=ft.FontWeight.BOLD,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        width=600,
        padding=ft.padding.symmetric(horizontal=10),
    )

    linea = ft.Container(
        width=1500,
        height=3,
        bgcolor=colors["azul_claro"],
        margin=ft.margin.symmetric(vertical=15),
        border_radius=2,
    )

    texto_bienvenida = ft.Text(
        value="",
        size=28,
        font_family="OCR-A",
        color=colors["azul_claro"],
        weight=ft.FontWeight.BOLD,
    )

    def iniciar_animacion(e):
        threading.Thread(
            target=texto_hacker,
            args=(page, texto_bienvenida, f"BIENVENIDO {usuario.upper()}"),
            daemon=True,
        ).start()

    text = ft.Container(
        content=ft.Column(
            [
                texto_bienvenida,
                ft.Container(height=15),
                ft.Text(
                    "Esta aplicación está diseñada con un solo propósito: proteger tu seguridad digital "
                    "En un mundo donde la privacidad se ve amenazada cada día por sistemas vulnerables y prácticas corruptas, "
                    "muchos usuarios han perdido el control sobre sus propios datos.",
                    color=colors["verde"],
                    font_family="OCR-A",
                    size=13,
                ),
                ft.Container(height=10),
                ft.Text(
                    "Por eso creamos esta app, para revolucionar la forma en que cuidás tu información "
                    "y demostrar que nuestros derechos a la privacidad también deben respetarse en Internet.",
                    color=colors["verde"],
                    font_family="OCR-A",
                    size=13,
                ),
                ft.Container(height=10),
                ft.Text(
                    "Con esta herramienta podrás guardar, encriptar y desencriptar tus archivos y contraseñas "
                    "de manera sencilla y segura, manteniendo tus datos lejos de miradas ajenas.",
                    color=colors["verde"],
                    font_family="OCR-A",
                    size=13,
                ),
                ft.Container(height=15),
                ft.Text(
                    "🔐 Recordá: el Internet nunca será completamente seguro, "
                    "pero vos tenés el poder de decidir si alguien puede vulnerarte… o si tu información sigue siendo solo tuya.",
                    color=colors["verde"],
                    font_family="OCR-A",
                    size=13,
                    italic=True,
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
            horizontal_alignment=ft.CrossAxisAlignment.START,
            alignment="center",
        ),
        bgcolor=colors["card"],
        padding=30,
        border_radius=15,
        width=600,
        height=480,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover_card,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=15,
            color=ft.Colors.with_opacity(0.5, colors["azul"]),
            offset=ft.Offset(0, 4),
        ),
    )

    text.on_mount = iniciar_animacion

    boton_encriptar_arch = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.LOCK, size=20),
                ft.Text("ENCRIPTAR ARCHIVOS", font_family="OCR-A", size=15),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
        ),
        on_click=ir_a_encriptar,
        width=280,
        height=55,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["azul"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        ),
    )

    boton_desencriptar_arch = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.LOCK_OPEN_ROUNDED, size=20),
                ft.Text("DESENCRIPTAR ARCHIVOS", font_family="OCR-A", size=15),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
        ),
        on_click=ir_a_desencriptar,
        width=280,
        height=55,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["verde"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        ),
    )

    boton_encriptar = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.LOCK_ROUNDED, size=20),
                ft.Text("ENCRIPTAR", font_family="OCR-A", size=15),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
        ),
        on_click=ir_a_encript,
        width=280,
        height=55,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["azul"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        ),
    )

    boton_desencriptar = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.LOCK_OPEN_ROUNDED, size=20),
                ft.Text("DESENCRIPTAR", font_family="OCR-A", size=15),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
        ),
        on_click=ir_a_desencript,
        width=280,
        height=55,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["verde"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        ),
    )

    boton_carpetas = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(ft.Icons.FOLDER_ROUNDED, size=20),
                ft.Text("CARPETAS", font_family="OCR-A", size=15),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
        ),
        on_click=ir_a_carpetas,
        width=280,
        height=55,
        scale=1.0,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["gris_claro"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        ),
    )

    boton_historial = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.HISTORY, size=20),
            ft.Text("HISTORIAL", font_family="OCR-A", size=15),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=10),
        on_click=lambda e: (page.clean(), __import__('pag_historial').main(page)),
        width=280,
        height=55,
        animate_scale=ft.Animation(300, "easeOut"),
        on_hover=hover,
        style=ft.ButtonStyle(
            bgcolor=colors["gris_claro"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            elevation=6,
        )
    )

    botones = ft.Column(
        controls=[
            boton_encriptar,
            boton_encriptar_arch,
            boton_desencriptar,
            boton_desencriptar_arch,
            boton_historial,
            boton_carpetas,
        ],
        alignment="center",
        spacing=15,
    )

    conte_prin = ft.Row(
        controls=[text, botones],
        alignment="center",
        vertical_alignment="center",
        spacing=60,
    )

    page.add(
        ft.Column(
            [
                header,
                linea,
                conte_prin,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )
    def iniciar_despues_render():
        time.sleep(0.3)  
        threading.Thread(
            target=texto_hacker,
            args=(page, texto_bienvenida, f"BIENVENIDO {usuario.upper()}"),
            daemon=True
        ).start()

    threading.Thread(target=iniciar_despues_render, daemon=True).start()

    page.update()
