# migrate_data.py - Script para migrar usuarios antiguos
"""
Este script migra usuarios del sistema antiguo (data.json con contraseñas en texto plano)
al nuevo sistema (data/users.json con contraseñas hasheadas)
"""

import json
import os
import bcrypt
from pathlib import Path
from datetime import datetime

OLD_FILE = "data.json"
NEW_FILE = "data/users.json"

def hash_password(password: str) -> str:
    """Hashea una contraseña usando bcrypt"""
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def migrate():
    """Migra usuarios del sistema antiguo al nuevo"""
    
    print("🔄 INICIANDO MIGRACIÓN DE DATOS")
    print("=" * 50)
    
    # Verificar si existe el archivo antiguo
    if not os.path.exists(OLD_FILE):
        print(f"❌ No se encontró el archivo {OLD_FILE}")
        print("   No hay nada que migrar.")
        return
    
    # Leer usuarios antiguos
    try:
        with open(OLD_FILE, "r") as f:
            usuarios_viejos = json.load(f)
        print(f"✅ Se encontraron {len(usuarios_viejos)} usuarios en {OLD_FILE}")
    except Exception as e:
        print(f"❌ Error leyendo {OLD_FILE}: {e}")
        return
    
    # Verificar si ya existe el archivo nuevo
    Path("data").mkdir(exist_ok=True)
    if os.path.exists(NEW_FILE):
        print(f"⚠️  El archivo {NEW_FILE} ya existe")
        respuesta = input("   ¿Deseas sobrescribirlo? (s/n): ")
        if respuesta.lower() != 's':
            print("❌ Migración cancelada")
            return
    
    # Migrar usuarios
    usuarios_nuevos = []
    print("\n🔐 Hasheando contraseñas...")
    
    for idx, usuario_viejo in enumerate(usuarios_viejos, 1):
        print(f"   [{idx}/{len(usuarios_viejos)}] Migrando: {usuario_viejo['usuario']}")
        
        # Hashear contraseña
        try:
            hashed = hash_password(usuario_viejo['contrasena'])
        except Exception as e:
            print(f"      ❌ Error hasheando contraseña: {e}")
            continue
        
        # Crear nuevo usuario
        usuario_nuevo = {
            "usuario": usuario_viejo['usuario'],
            "correo": usuario_viejo.get('correo', ''),
            "contrasena": hashed,  # ✅ HASHEADA
            "fecha_registro": datetime.now().isoformat(),
            "ultimo_acceso": None,
            "intentos_fallidos": 0,
            "bloqueado": False
        }
        
        usuarios_nuevos.append(usuario_nuevo)
    
    # Guardar nuevos usuarios
    try:
        with open(NEW_FILE, "w") as f:
            json.dump(usuarios_nuevos, f, indent=4)
        print(f"\n✅ Se migraron {len(usuarios_nuevos)} usuarios a {NEW_FILE}")
    except Exception as e:
        print(f"\n❌ Error guardando {NEW_FILE}: {e}")
        return
    
    # Hacer backup del archivo antiguo
    backup_file = "data.json.backup"
    try:
        os.rename(OLD_FILE, backup_file)
        print(f"📦 Backup creado: {backup_file}")
    except Exception as e:
        print(f"⚠️  No se pudo crear backup: {e}")
    
    print("\n" + "=" * 50)
    print("✅ MIGRACIÓN COMPLETADA EXITOSAMENTE")
    print("=" * 50)
    print("\n📝 IMPORTANTE:")
    print("   1. Los usuarios pueden iniciar sesión con sus contraseñas anteriores")
    print("   2. Las contraseñas ahora están hasheadas con bcrypt")
    print("   3. Se creó un backup en:", backup_file)
    print("   4. Cada usuario ahora tiene su propia clave de encriptación")
    print("\n⚠️  NOTA SOBRE ARCHIVOS ENCRIPTADOS:")
    print("   Los archivos encriptados con el sistema antiguo NO podrán")
    print("   desencriptarse con el nuevo sistema (diferentes claves).")
    print("   Para mantener compatibilidad, conservá el archivo 'data/secret.key'")

if __name__ == "__main__":
    migrate()