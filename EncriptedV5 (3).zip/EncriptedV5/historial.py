import json
import os
import datetime

def guardar_en_historial(nombre, accion, ruta, tamaño):
    """Guarda un registro de archivo en el historial.json"""
    registro = {
        "archivo": nombre,
        "accion": accion,
        "fecha": datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        "ruta": ruta,
        "tamano": f"{round(tamaño / 1024, 2)} KB"
    }

    if not os.path.exists("historial.json"):
        with open("historial.json", "w") as f:
            json.dump([], f)

    with open("historial.json", "r") as f:
        data = json.load(f)

    data.append(registro)

    with open("historial.json", "w") as f:
        json.dump(data, f, indent=4)
