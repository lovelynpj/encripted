import flet as ft
import os 
import sys
os.system("cls")
import pag_log

exit = sys.exit

colors = {
    "fondo": "#0A0F1C",
    "card": "#131313",
    "gris": "#1e1e1e",
    "gris_claro": "#2D2D2D",
    "gris_oscuro": "#000017",
    "blanco": "#FFFFFF",
    "azul": "#048ef7",
    "azul_claro": "#3e7be6",
    "azul_oscuro": "#070758",
    "rojo": "#Ad1A1A",
    "verde": "#4db139",
}

def main(page: ft.Page):
    page.title = "---3NCR1PT3D---"
    page.padding = 30
    page.bgcolor = colors["fondo"]
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    def pag_log_click(e):
        page.clean()
        pag_log.main(page)

    boton_continuar = ft.ElevatedButton(
        "CONTINUAR",
        on_click=pag_log_click,
        width=280,
        height=55,
        style=ft.ButtonStyle(
            bgcolor=colors["azul"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=12),
            text_style=ft.TextStyle(
                font_family="OCR-A",
                size=16,
                weight=ft.FontWeight.BOLD
            ),
            elevation=8,
        )
    )
    
    carta = ft.Container(
        content=ft.Column(
            [
                ft.Container(
                    content=ft.Text(
                        "WELCOME TO",
                        size=24,
                        font_family="OCR-A",
                        color=colors["gris_claro"],
                        weight=ft.FontWeight.W_300
                    ),
                    margin=ft.margin.only(bottom=5)
                ),
                ft.Container(
                    content=ft.Text(
                        "3NCR1PT3D",
                        size=42,
                        font_family="OCR-A",
                        color=colors["azul_claro"],                                                             
                        weight=ft.FontWeight.BOLD
                    ),
                    margin=ft.margin.only(bottom=10)
                ),
                ft.Container(
                    width=200,
                    height=3,
                    bgcolor=colors["azul"],
                    border_radius=2,
                    margin=ft.margin.only(bottom=30)
                ),
                ft.Text(
                    "Tu privacidad es nuestra prioridad",
                    size=14,
                    font_family="OCR-A",
                    color=colors["verde"],
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=30),
                boton_continuar,
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER
        ),
        bgcolor=colors["card"],
        padding=40,
        border_radius=20,
        width=450,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=20,
            color=ft.Colors.with_opacity(0.6, colors["azul"]),
            offset=ft.Offset(0, 5),
        )
    )
    
    page.add(carta)


if __name__ == "__main__":
    os.environ["FLET_FORCE_WEBVIEW"] = "1"   
    ft.app(target=main)
