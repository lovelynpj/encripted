# pag_encriptar.py - VERSIÓN MEJORADA
import flet as ft
from flet import Colors
from pathlib import Path
from historial import guardar_en_historial
from encriptacion_desencriptacion import encrypt_bytes, export_key
from gestor_archivos import save_text_file_for_user
import os

colors = {
    "fondo": "#0A0F1C",
    "card": "#131313",
    "gris": "#1e1e1e",
    "gris_claro": "#2D2D2D",
    "blanco": "#FFFFFF",
    "azul": "#048ef7",
    "azul_claro": "#3e7be6",
    "rojo": "#Ad1A1A",
    "verde": "#4db139",
}

DEFAULT_FOLDER = "mis_archivos"

def get_current_user(page: ft.Page):
    try:
        u = page.session.get("usuario_actual")
        if u:
            return u
    except Exception:
        pass
    return "usuario_demo"

def get_user_password(page: ft.Page):
    """Obtiene la contraseña del usuario desde la sesión"""
    try:
        pwd = page.session.get("password_cache")
        if pwd:
            return pwd
    except Exception:
        pass
    return None

def main(page: ft.Page):
    page.title = "Encriptar archivos"
    page.window_width = 900
    page.window_height = 700
    page.bgcolor = colors["fondo"]

    usuario = get_current_user(page)
    password = get_user_password(page)

    file_picker = ft.FilePicker()
    page.overlay.append(file_picker)

    selected_label = ft.Text(
        "No hay archivo seleccionado",
        font_family="OCR-A",
        selectable=True,
        color=colors["gris_claro"]
    )
    
    resultado = ft.Text("", selectable=True, font_family="OCR-A", no_wrap=False)
    
    # Progress bar
    progress = ft.ProgressBar(
        width=400,
        color=colors["azul_claro"],
        bgcolor=colors["gris"],
        visible=False
    )
    
    progress_text = ft.Text("", size=12, color=colors["azul_claro"], visible=False)

    # Información del archivo
    file_info = ft.Column(visible=False, spacing=5)

    def ir_a_principal(e):
        from pag_prin import main as pag_prin
        page.clean()
        pag_prin(page)

    def pick_file(e):
        file_picker.pick_files(allow_multiple=False)

    def format_size(bytes):
        """Formatea el tamaño del archivo"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes < 1024.0:
                return f"{bytes:.2f} {unit}"
            bytes /= 1024.0
        return f"{bytes:.2f} TB"

    def on_file_picked(e: ft.FilePickerResultEvent):
        if e.files:
            f = e.files[0]
            selected_label.value = f"📄 {f.name}"
            selected_label.color = colors["blanco"]
            selected_label.data = f.path
            
            # Mostrar información del archivo
            size = os.path.getsize(f.path)
            file_info.controls.clear()
            file_info.controls.append(
                ft.Text(f"📦 Tamaño: {format_size(size)}", size=12, color=colors["azul_claro"])
            )
            file_info.controls.append(
                ft.Text(f"📂 Ruta: {f.path}", size=10, color=colors["gris_claro"], no_wrap=False)
            )
            file_info.visible = True
            
            resultado.value = ""
        else:
            selected_label.value = "No se seleccionó archivo"
            selected_label.color = colors["gris_claro"]
            selected_label.data = None
            file_info.visible = False
        page.update()

    file_picker.on_result = on_file_picked

    def on_encrypt_click(e):
        ruta = getattr(selected_label, "data", None)
        if not ruta:
            page.snack_bar = ft.SnackBar(
                ft.Text("⚠️ Seleccioná un archivo primero", font_family="OCR-A")
            )
            page.snack_bar.open = True
            page.update()
            return
        
        if not password:
            page.snack_bar = ft.SnackBar(
                ft.Text("❌ Error: No se pudo obtener la contraseña", font_family="OCR-A")
            )
            page.snack_bar.open = True
            page.update()
            return
        
        try:
            # Mostrar progress
            progress.visible = True
            progress.value = None  # Indeterminado
            progress_text.visible = True
            progress_text.value = "🔐 Encriptando archivo..."
            btn_encrypt.disabled = True
            btn_select.disabled = True
            page.update()
            
            # Leer archivo
            with open(ruta, "rb") as f:
                data = f.read()
            
            progress_text.value = "🔒 Aplicando encriptación..."
            page.update()
            
            # Encriptar con usuario y contraseña
            token_bytes = encrypt_bytes(data, usuario, password)
            token_text = token_bytes.decode("utf-8")
            
            progress_text.value = "💾 Guardando archivo..."
            page.update()
            
            # Guardar
            out_filename = Path(ruta).name + ".enc"
            out_path = save_text_file_for_user(usuario, DEFAULT_FOLDER, out_filename, token_text)
            
            # Historial
            tamaño = os.path.getsize(ruta)
            guardar_en_historial(os.path.basename(ruta), "ENCRIPTAR", ruta, tamaño)
            
            # Completado
            progress.value = 1.0
            progress_text.value = "✅ Completado"
            page.update()
            
            import time
            time.sleep(0.5)
            
            resultado.value = f"✅ Archivo encriptado exitosamente\n📁 Guardado en: {out_path}"
            resultado.color = Colors.GREEN
            
            page.snack_bar = ft.SnackBar(
                ft.Text("✅ Archivo encriptado correctamente", font_family="OCR-A")
            )
            page.snack_bar.open = True
            
        except Exception as ex:
            resultado.value = f"❌ Error: {str(ex)}"
            resultado.color = Colors.RED
            progress_text.value = "❌ Error en la encriptación"
            
        finally:
            progress.visible = False
            progress_text.visible = False
            btn_encrypt.disabled = False
            btn_select.disabled = False
            page.update()

    def on_export_key(e):
        export_path = Path("data") / f"{usuario}_key_backup.key"
        export_path.parent.mkdir(parents=True, exist_ok=True)
        
        if export_key(usuario, str(export_path)):
            page.snack_bar = ft.SnackBar(
                ft.Text(f"🔑 Clave exportada a: {export_path}", font_family="OCR-A")
            )
        else:
            page.snack_bar = ft.SnackBar(
                ft.Text("❌ Error al exportar la clave", font_family="OCR-A")
            )
        page.snack_bar.open = True
        page.update()

    btn_select = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.FOLDER_ROUNDED, size=20),
            ft.Text("SELECCIONAR", font_family="OCR-A"),
        ], spacing=8),
        on_click=pick_file,
        width=180,
        height=45,
        style=ft.ButtonStyle(
            bgcolor=colors["azul"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=10),
            elevation=5,
        )
    )

    btn_encrypt = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.LOCK, size=20),
            ft.Text("ENCRIPTAR", font_family="OCR-A"),
        ], spacing=8),
        on_click=on_encrypt_click,
        width=180,
        height=45,
        style=ft.ButtonStyle(
            bgcolor=colors["verde"],
            color=colors["blanco"],
            shape=ft.RoundedRectangleBorder(radius=10),
            elevation=5,
        )
    )

    btn_export = ft.OutlinedButton(
        content=ft.Row([
            ft.Icon(ft.Icons.KEY, size=18),
            ft.Text("EXPORTAR CLAVE", font_family="OCR-A", size=12),
        ], spacing=5),
        on_click=on_export_key,
        width=180,
        height=40,
        style=ft.ButtonStyle(
            side=ft.BorderSide(2, colors["azul_claro"]),
            color=colors["azul_claro"],
            shape=ft.RoundedRectangleBorder(radius=10),
        )
    )

    card = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Icon(ft.Icons.FOLDER_OPEN, color=colors["azul_claro"], size=24),
                ft.Text("Archivo seleccionado:", weight="bold", font_family="OCR-A", color=colors["azul_claro"])
            ], spacing=10),
            ft.Container(height=10),
            selected_label,
            file_info,
            ft.Container(height=20),
            ft.Row([btn_select, btn_encrypt], spacing=12, alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=10),
            progress,
            progress_text,
            ft.Container(height=10),
            ft.Container(
                content=resultado,
                padding=15,
                bgcolor=colors["gris"],
                border_radius=10,
                width=600,
                visible=True
            ),
            ft.Container(height=10),
            ft.Divider(color=colors["azul_claro"], height=1),
            ft.Container(height=5),
            btn_export,
            ft.Container(height=5),
            ft.Text(
                "ℹ️ Los archivos se guardan en data/usuarios/<tu_usuario>/mis_archivos/",
                font_family="OCR-A",
                color=colors["gris_claro"],
                size=11
            )
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        bgcolor=colors["card"],
        padding=30,
        border_radius=15,
        width=670,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=15,
            color=ft.Colors.with_opacity(0.5, colors["azul"]),
            offset=ft.Offset(0, 4),
        ),
    )

    btn_volver = ft.IconButton(
        icon=ft.Icons.ARROW_BACK_ROUNDED,
        icon_color=colors["azul_claro"],
        icon_size=28,
        on_click=ir_a_principal,
        tooltip="Volver al menú principal"
    )

    page.add(
        ft.Column([
            ft.Row([
                btn_volver,
                ft.Text(
                    "🔐 Encriptación de Archivos",
                    size=26,
                    color=colors["azul_claro"],
                    font_family="OCR-A"
                ),
            ], alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=20),
            card
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        scroll=ft.ScrollMode.AUTO,
        )
    )
