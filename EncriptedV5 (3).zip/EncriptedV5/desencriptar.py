# desencriptar.py - VERSIÓN MEJORADA
import flet as ft
import os
os.system("cls")
from encriptacion_desencriptacion import decrypt_message

colors = {
    "fondo": "#0A0F1C",
    "card": "#131313",
    "gris": "#1e1e1e",
    "gris_claro": "#2D2D2D",
    "gris_oscuro": "#000017",
    "blanco": "#FFFFFF",
    "azul": "#048ef7",
    "azul_claro": "#3e7be6",
    "azul_oscuro": "#070758",
    "rojo": "#Ad1A1A",
    "verde": "#4db139",
}

def get_current_user(page: ft.Page):
    try:
        u = page.session.get("usuario_actual")
        if u:
            return u
    except Exception:
        pass
    return "usuario_demo"

def get_user_password(page: ft.Page):
    """Obtiene la contraseña del usuario desde la sesión"""
    try:
        pwd = page.session.get("password_cache")
        if pwd:
            return pwd
    except Exception:
        pass
    return None

def main(page: ft.Page):
    page.controls.clear()
    page.title = "---3NCR1PT3D---"
    page.padding = 30
    page.bgcolor = colors["fondo"]
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    usuario = get_current_user(page)
    password = get_user_password(page)
    
    def ir_a_principal(e):
        from pag_prin import main as pag_prin
        page.clean()
        pag_prin(page)
    
    header = ft.Container(
        content=ft.Row(
            [
                ft.IconButton(
                    icon=ft.Icons.ARROW_BACK_ROUNDED,
                    icon_color=colors["azul_claro"],
                    icon_size=28,
                    on_click=ir_a_principal,
                    tooltip="Volver al menú principal"
                ),
                ft.Text(
                    "DESENCRIPTAR TEXTO",
                    color=colors["verde"],
                    size=32,
                    font_family="OCR-A",
                    weight=ft.FontWeight.BOLD
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=15,
        ),
        margin=ft.margin.only(bottom=20)
    )
    
    input_text = ft.TextField(
        label="Ingresa el texto encriptado",
        width=350,
        multiline=True,
        min_lines=3,
        max_lines=5,
        color=colors["blanco"],
        border_color=colors["verde"],
        focused_border_color=colors["azul_claro"],
        text_style=ft.TextStyle(font_family="Lucida Sans Typewriter", size=14)
    )
    
    resultado = ft.Text(
        "",
        size=12,
        selectable=True,
        color=colors["azul_claro"],
        no_wrap=False,
        expand=True
    )
    
    # Progress indicator
    loading = ft.ProgressRing(
        visible=False,
        width=20,
        height=20,
        color=colors["verde"]
    )
    
    def on_decrypt(e):
        if not input_text.value or not input_text.value.strip():
            resultado.value = "⚠️ Por favor ingresa un texto encriptado"
            resultado.color = colors["rojo"]
            page.update()
            return
        
        if not password:
            resultado.value = "❌ Error: No se pudo obtener la contraseña de sesión"
            resultado.color = colors["rojo"]
            page.update()
            return
        
        try:
            # Mostrar loading
            loading.visible = True
            page.update()
            
            token = input_text.value
            
            # ✅ CORREGIDO: Pasar usuario y contraseña
            texto_plano = decrypt_message(token, usuario, password)
            
            resultado.value = texto_plano
            resultado.color = colors["azul_claro"]
            
            loading.visible = False
            
            page.snack_bar = ft.SnackBar(
                ft.Text("✅ Texto desencriptado exitosamente", font_family="OCR-A")
            )
            page.snack_bar.open = True
            
        except Exception as ex:
            resultado.value = f"❌ Error al desencriptar: {str(ex)}\nVerificá que el texto sea válido y que sea tuyo."
            resultado.color = colors["rojo"]
            loading.visible = False
        
        page.update()
    
    def on_clear(e):
        input_text.value = ""
        resultado.value = ""
        page.update()
    
    def on_copy(e):
        if resultado.value and not resultado.value.startswith("⚠️") and not resultado.value.startswith("❌"):
            page.set_clipboard(resultado.value)
            page.snack_bar = ft.SnackBar(
                ft.Text("📋 Copiado al portapapeles", font_family="OCR-A")
            )
            page.snack_bar.open = True
            page.update()
    
    carta_input = ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(ft.Icons.LOCK_OPEN_ROUNDED, color=colors["verde"], size=24),
                        ft.Text("Texto Encriptado", size=20, font_family="OCR-A", color=colors["verde"]),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10,
                ),
                ft.Container(height=15),
                input_text,
                ft.Container(height=20),
                ft.Row(
                    [
                        ft.ElevatedButton(
                            content=ft.Row(
                                [
                                    ft.Icon(ft.Icons.LOCK_OPEN_ROUNDED, size=18),
                                    ft.Text("DESENCRIPTAR", font_family="OCR-A"),
                                ],
                                spacing=8,
                            ),
                            on_click=on_decrypt,
                            width=170,
                            height=45,
                            style=ft.ButtonStyle(
                                bgcolor=colors["verde"],
                                color=colors["blanco"],
                                shape=ft.RoundedRectangleBorder(radius=10),
                                elevation=5,
                            )
                        ),
                        ft.OutlinedButton(
                            content=ft.Row(
                                [
                                    ft.Icon(ft.Icons.CLEAR_ROUNDED, size=18),
                                    ft.Text("LIMPIAR", font_family="OCR-A"),
                                ],
                                spacing=8,
                            ),
                            on_click=on_clear,
                            width=160,
                            height=45,
                            style=ft.ButtonStyle(
                                side=ft.BorderSide(2, colors["verde"]),
                                color=colors["verde"],
                                shape=ft.RoundedRectangleBorder(radius=10),
                            )
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=15,
                ),
                ft.Container(height=10),
                loading,
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        bgcolor=colors["card"],
        padding=30,
        border_radius=15,
        width=450,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=15,
            color=ft.Colors.with_opacity(0.5, colors["verde"]),
            offset=ft.Offset(0, 4),
        ),
    )
    
    carta_resultado = ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(ft.Icons.CHECK_CIRCLE_OUTLINE_ROUNDED, color=colors["azul_claro"], size=24),
                        ft.Text("Resultado", size=20, font_family="OCR-A", color=colors["azul_claro"]),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10,
                ),
                ft.Container(height=15),
                ft.Container(
                    content=resultado,
                    bgcolor=colors["gris"],
                    padding=15,
                    border_radius=10,
                    width=350,
                    height=100,
                    border=ft.border.all(1, colors["verde"])
                ),
                ft.Container(height=10),
                ft.IconButton(
                    icon=ft.Icons.CONTENT_COPY,
                    icon_color=colors["azul_claro"],
                    tooltip="Copiar resultado",
                    on_click=on_copy
                )
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        bgcolor=colors["card"],
        padding=30,
        border_radius=15,
        width=450,
        shadow=ft.BoxShadow(
            spread_radius=1,
            blur_radius=15,
            color=ft.Colors.with_opacity(0.5, colors["verde"]),
            offset=ft.Offset(0, 4),
        ),
    )
    
    page.add(
        header,
        carta_input,
        ft.Container(height=20),
        carta_resultado
    )
    page.update()


